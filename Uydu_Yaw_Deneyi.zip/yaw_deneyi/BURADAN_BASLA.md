# Uydu: bugün yapılacak yaw ve manyetik bozulma deneyi

## 20 dakikada somut çıktı
1. ZIP'i aç; MATLAB Current Folder olarak yaw_deneyi klasörünü seç.
2. Command Window'a `yaw_deneyi` yaz. Ek toolbox gerekmez.
3. Açılan üç grafikte yön tahmini, gerçek yöne göre hata ve pusulanın kullanılıp kullanılmadığını gör.
4. Dosyanın başındaki `scenario = 'ani'` değerini önce `'temiz'`, sonra `'yavas'` yapıp tekrar çalıştır.
5. Her çalışmada senaryo adına göre iki CSV yazılır. Aynı senaryoyu tekrar çalıştırmak önceki sonucunu değiştirir.
6. Bugünün teslimi: üç senaryo için maksimum/RMS hata tablosu ve bozuk pusula ölçümünü ne zaman eleyeceğimizi açıklayan bir paragraf.

## Dosyalar
- yaw_deneyi.m: MATLAB'da çalıştıracağın kod. Bu ortamda MATLAB bulunmadığı için burada MATLAB ile çalıştırılmadı.
- yaw_deneyi.py: Aynı hesapların Python karşılığı; burada çalıştırılıp kontrolleri yapıldı. Python 3, NumPy, Matplotlib ister.
- karsilastirma.png: Üç senaryonun Python ile üretilmiş hata grafikleri.
- sonuclar.json: Sayısal özet.
- *_veri.csv: Sentetik zaman serileri; gerçek sensör ölçümü değildir.
- donanim_test_formu.tsv: İleride gerçek sensörle doldurulacak boş form; simülasyon sonucu ile karıştırma.

## Model ne yapar?
300 s, 100 Hz örnekleme. Gerçek yaw=8*sin(2*pi*t/10) derece.
Platform YATAY kabul edilir; roll/pitch ve eğim telafisi bu deneyde yok.
Jiroskop ölçümü gerçek açının sonlu farkından üretilir, üstüne varsayımsal 0.01 derece/s
kalıntı ofset ve deterministik dalgalanma eklenir. Bu değer BMI088 datasheet değeri değildir.
Başlangıç yönü tam biliniyor kabul edilir. Pusulaya varsayımsal ölçüm dalgalanması eklenir.
'ani': 60-90 saniye arasında pusulada +15 derece hata.
'yavas': 60-160 saniye arasında pusula hatası 0'dan +8 dereceye çıkar ve kalır.
Manyetik alan büyüklüğü tüm senaryolarda 50 uT tutulur; yalnız yön değiştirilir.
Bu, motorun gerçek manyetik alan modeli değildir. Büyüklük kontrolünün tek başına
hata yakalayamayacağını göstermek için hazırlanmış sentetik ölçüm senaryosudur.

Üç yöntem:
1. Yalnız jiroskop: hızı toplar; ofset nedeniyle kayar.
2. Sürekli pusula: jiroskop tahminini pusulaya doğru 1 s zaman sabitiyle düzeltir.
3. Ölçüm eleyen: aynı düzeltmeyi sadece pusula-yön tahmini farkı 5 dereceden küçük ve
alan büyüklüğü referansın ±%20'si içindeyse uygular.
Bu eşikler öğretim içindir; gerçek sistem veya yarışma kabul sınırı değildir.
Gerçek açı yalnızca grafik/hata hesabında kullanılır; filtre kararına verilmez.

## Önemli sonuç
Ani büyük bozulma yakalanabilir; yavaş değişen hata filtreyi kandırabilir.
Sadece bir eşik koymak manyetik sorunu çözmez. Pusula uzun süre reddedilirse gyro kayması sürer.
Başlangıç hizası hatası, sensör gecikmesi, üç boyutlu hareket, sıcaklık, motor/encoder
mekaniği ve hedef düzlemindeki lazer konumu bu modelde bulunmaz.
Enkoderler ve çanak IMU'su bu ilk yaw tahmini deneyine dahil değildir.
Bu paket ilk elevasyon simülasyonundan ayrı bir sensör algoritması deneyidir.

## Sonra yapacağın iki değişiklik
A. 'ani' senaryosunda gate_deg=20 yap: bozuk pusulanın kabul edilmesini ve hata artışını gör.
B. bias=0.05 yap: pusula reddedildiğinde gyro hatasının daha hızlı büyüdüğünü gör.
Her değişiklikten sonra varsayılanlara dön. Farklı denemelerin CSV dosyalarını ayrı adla sakla.

## Donanım gelince aynı soruyu ölçerek yanıtla
Alt taban ve ona bağlı sensörü sabit tut; yalnız üst eksenleri hareket ettir.
10/20/30 cm aday yerleşimlerde motorlar kapalı, tutma akımında, azimut hareketli,
elevasyon hareketli ve birlikte hareketli durumlarını dene. Mesafeler garanti değildir.
Her durumda ham mx,my,mz, gyro, ivme, yön tahmini, eksen açıları, sürücü akım ayarı ve zaman kaydet.
Aynı yön ve yük koşullarında tekrar et. Yerleşim kıyasını yalnız motor-kapalı tek referansa
bakıp bitirme; farklı platform yön/eğimleriyle de tekrar et. Harici yön referansıyla
hata doğrulanmalı; filtrenin kendi tahmini tek başına doğruluk kanıtı olamaz.
İzin verilen hedef sapması ve mesafe belirlenmeden PASSED/FAILED eşiği koyma.
Motorların yanında güvenilir manyetik referans elde edilemiyorsa bu algoritma yeterli değildir.

## Teknik arka plan
https://www.vectornav.com/resources/inertial-navigation-primer/specifications--and--error-budgets/specs-magerrorsources
https://www.vectornav.com/resources/inertial-navigation-primer/specifications--and--error-budgets/specs-hsicalibration
https://www.nxp.com/docs/en/application-note/AN4247.pdf
