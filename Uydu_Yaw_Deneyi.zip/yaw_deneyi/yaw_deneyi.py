from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import json
P=Path(__file__).resolve().parent

def run(scenario='ani',bias=.01,threshold=5):
    dt=.01; t=np.arange(30001)*dt
    truth=8*np.sin(2*np.pi*t/10)
    gyro=np.r_[0,np.diff(truth)/dt]+bias+.02*np.sin(2*np.pi*7*t)
    disturbance=np.zeros_like(t)
    if scenario=='ani':disturbance[(t>=60)&(t<90)]=15
    elif scenario=='yavas':disturbance=8*np.clip((t-60)/100,0,1)
    elif scenario!='temiz':raise ValueError(scenario)
    mag=truth+disturbance+.1*np.sin(2*np.pi*.7*t)
    # Constant magnitude: demonstrates why magnitude-only detection is insufficient.
    mx=50*np.cos(np.deg2rad(mag));my=50*np.sin(np.deg2rad(mag));mz=0*t
    field=np.sqrt(mx*mx+my*my+mz*mz)
    estimates=np.zeros((3,len(t))); accepted=np.zeros(len(t),dtype=bool)
    wrap=lambda x:(x+180)%360-180
    gain=1-np.exp(-dt/1.)
    for k in range(1,len(t)):
        pred=estimates[:,k-1]+gyro[k]*dt
        estimates[0,k]=pred[0]
        estimates[1,k]=pred[1]+gain*wrap(mag[k]-pred[1])
        innovation=wrap(mag[k]-pred[2])
        accepted[k]=abs(innovation)<threshold and abs(field[k]/50-1)<.2
        estimates[2,k]=pred[2]+(gain*innovation if accepted[k] else 0)
    err=wrap(estimates-truth)
    names=['yalniz_gyro','surekli_pusula','olcum_eleyen']
    metrics={name:{'max_error_deg':float(np.max(np.abs(err[i]))),'rms_error_deg':float(np.sqrt(np.mean(err[i]**2))),'end_error_deg':float(err[i,-1])} for i,name in enumerate(names)}
    metrics['rejected_percent']=float(100*np.mean(~accepted[1:]))
    return t,truth,mag,estimates,err,accepted,metrics

if __name__=='__main__':
    summary={}
    fig,axes=plt.subplots(3,1,figsize=(10,8),layout='constrained')
    for ax,scenario in zip(axes,['temiz','ani','yavas']):
        t,truth,mag,est,err,ok,metrics=run(scenario);summary[scenario]=metrics
        for i,label in enumerate(['Yalniz jiroskop','Pusulayi hep kullan','Supheli olcumu ele']):ax.plot(t,err[i],label=label)
        ax.set_title({'temiz':'Manyetik bozucu yok','ani':'60-90 s: +15 derece ani manyetik hata','yavas':'60-160 s: 0 dan +8 dereceye yavas manyetik hata'}[scenario]);ax.set_ylabel('Yaw hatasi (derece)');ax.grid(alpha=.3)
        np.savetxt(P/f'{scenario}_veri.csv',np.column_stack([t,truth,mag,est.T,ok.astype(int)]),delimiter=',',header='time_s,true_yaw_deg,mag_yaw_deg,gyro_yaw_deg,always_fused_yaw_deg,gated_yaw_deg,mag_accepted',comments='')
    axes[0].legend();axes[-1].set_xlabel('Zaman (s)')
    fig.suptitle('SENTETIK VERI - yaw olcum algoritmasi deneyi / donanim sonucu degildir')
    fig.savefig(P/'karsilastirma.png',dpi=140)
    (P/'sonuclar.json').write_text(json.dumps(summary,indent=2))
    assert summary['ani']['olcum_eleyen']['max_error_deg']<summary['ani']['surekli_pusula']['max_error_deg']
    assert summary['yavas']['olcum_eleyen']['max_error_deg']>5
    assert abs(summary['temiz']['yalniz_gyro']['end_error_deg']-3)<.001
    print(json.dumps(summary,indent=2))
