% YAW DENEYI - Sentetik veri. Donanim/motor dogrulamasi DEGIL.
% Yalniz yaw: platform yatay kabul edilir. Ek toolbox gerektirmez.
clear; clc; close all;
scenario = 'ani'; % 'temiz', 'ani' veya 'yavas'
bias = 0.01;      % Kalibrasyon sonrasi KALAN gyro ofseti, derece/s; varsayim
gate_deg = 5;     % Ornek eleme esigi; yarişma toleransi DEGIL
T = 300; dt = 0.01; t = 0:dt:T;
yaw_true = 8*sin(2*pi*t/10);
gyro = [0 diff(yaw_true)/dt] + bias + 0.02*sin(2*pi*7*t);
disturbance = zeros(size(t));
switch scenario
 case 'ani'
  disturbance(t>=60 & t<90) = 15;
 case 'yavas'
  disturbance = 8*min(max((t-60)/100,0),1);
 case 'temiz'
 otherwise
  error('scenario: temiz, ani veya yavas olmali');
end
mag_yaw = yaw_true + disturbance + 0.1*sin(2*pi*0.7*t);
% 50 uT sabit buyukluk, degisen alan yonu: buyukluk testi tek basina yetmez.
mx=50*cos(mag_yaw*pi/180); my=50*sin(mag_yaw*pi/180); mz=zeros(size(t));
field=sqrt(mx.^2+my.^2+mz.^2);
est=zeros(3,numel(t)); accepted=false(size(t));
wrap=@(x) mod(x+180,360)-180;
gain=1-exp(-dt/1.0); % 1 s ornek duzeltme zaman sabiti
for k=2:numel(t)
 pred=est(:,k-1)+gyro(k)*dt;
 est(1,k)=pred(1);
 est(2,k)=pred(2)+gain*wrap(mag_yaw(k)-pred(2));
 innovation=wrap(mag_yaw(k)-pred(3));
 accepted(k)=abs(innovation)<gate_deg && abs(field(k)/50-1)<0.20;
 est(3,k)=pred(3);
 if accepted(k), est(3,k)=pred(3)+gain*innovation; end
end
err=wrap(est-repmat(yaw_true,3,1));
method={'Yalniz gyro';'Surekli pusula';'Olcum eleyen'};
results=table(method,max(abs(err),[],2),sqrt(mean(err.^2,2)),err(:,end),...
 'VariableNames',{'Yontem','MaxHata_deg','RMSHata_deg','SonHata_deg'});
disp(results);
fprintf('Elenen pusula olcumu: %.2f %%\n',100*mean(~accepted(2:end)));
figure('Name','Sentetik yaw deneyi');
subplot(3,1,1);plot(t,yaw_true,'k--',t,est');ylabel('Yaw (derece)');grid on;
legend('Gercek','Gyro','Surekli pusula','Olcum eleyen');title(['SENTETIK VERI: ' scenario]);
subplot(3,1,2);plot(t,err');ylabel('Hata (derece)');grid on;
subplot(3,1,3);stairs(t,double(accepted));ylim([-.1 1.1]);ylabel('Pusula kabul (0/1)');xlabel('Zaman (s)');grid on;
writetable(results,[scenario '_matlab_ozet.csv']);
writetable(table(t',yaw_true',mag_yaw',est(1,:)',est(2,:)',est(3,:)',accepted',...
 'VariableNames',{'time_s','true_yaw_deg','mag_yaw_deg','gyro_yaw_deg','always_fused_yaw_deg','gated_yaw_deg','mag_accepted'}),[scenario '_matlab_veri.csv']);
